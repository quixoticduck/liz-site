<?php
namespace Craft;

define('CRAFT_VERSION', '2.6');
define('CRAFT_BUILD', '2780');
define('CRAFT_SCHEMA_VERSION', '2.6.3');
define('CRAFT_RELEASE_DATE', '1459892307');
define('CRAFT_MIN_BUILD_REQUIRED', '2570');
define('CRAFT_MIN_BUILD_URL', 'https://download.craftcdn.com/craft/2.1/2.1.2570/Craft-2.1.2570.zip');
define('CRAFT_TRACK', 'stable');
